const { Client } = require('pg');
require('dotenv').config();

const client = new Client({
  connectionString: process.env.DATABASE_URL
});

async function run() {
  await client.connect();
  const res = await client.query('UPDATE users SET is_verified = true WHERE is_verified = false');
  console.log(`Verified ${res.rowCount} users.`);
  await client.end();
}

run().catch(console.error);
