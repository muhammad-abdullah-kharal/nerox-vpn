const { Client } = require('pg');
const c = new Client({ connectionString: 'postgresql://postgres:NewPassword123@localhost:5432/nerox_vpn' });

c.connect()
  .then(() => c.query(`SELECT user_id, email, is_verified FROM users WHERE email = 'dde@gmail.com'`))
  .then(r => { 
    console.log(JSON.stringify(r.rows, null, 2)); 
    c.end(); 
  })
  .catch(e => { 
    console.error(e.message); 
    c.end(); 
  });
