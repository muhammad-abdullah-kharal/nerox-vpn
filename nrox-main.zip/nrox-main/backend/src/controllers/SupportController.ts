import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';

// ---------------------------------------------------------------------------
// Supabase REST helper
// ---------------------------------------------------------------------------
// We talk directly to Supabase instead of the local Postgres pool so that
// feedback is visible in the admin panel (which also reads from Supabase).
// The service_role key is required to bypass Row Level Security.

const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const TABLE = 'support_feedback';

interface SupabaseRequestOptions {
  method: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  path: string;          // everything after /rest/v1/
  body?: object;
  prefer?: string;       // e.g. 'return=representation'
}

async function supabaseRequest<T = any>(opts: SupabaseRequestOptions): Promise<T> {
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    throw new Error(
      'SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY is not set in environment variables.'
    );
  }

  const url = `${SUPABASE_URL}/rest/v1/${opts.path}`;
  const headers: Record<string, string> = {
    'Content-Type':  'application/json',
    'apikey':        SUPABASE_KEY,
    'Authorization': `Bearer ${SUPABASE_KEY}`,
  };

  if (opts.prefer) {
    headers['Prefer'] = opts.prefer;
  }

  const response = await fetch(url, {
    method:  opts.method,
    headers,
    body:    opts.body ? JSON.stringify(opts.body) : undefined,
  });

  const text = await response.text();
  let data: any;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }

  if (!response.ok) {
    const msg = data?.message || data?.error || JSON.stringify(data) || response.statusText;
    throw new Error(`Supabase error ${response.status}: ${msg}`);
  }

  return data as T;
}

// ---------------------------------------------------------------------------

export class SupportController {

  // POST /api/support/feedback
  static async submitFeedback(req: AuthRequest, res: Response) {
    try {
      const { category, subject, message } = req.body;
      const userId = req.user?.userId;

      if (!message || !userId) {
        return res.status(400).json({ error: 'Message is required' });
      }

      await supabaseRequest({
        method: 'POST',
        path:   TABLE,
        prefer: 'return=minimal',
        body:   { user_id: userId, category, subject, message },
      });

      res.json({ success: true, message: 'Feedback submitted successfully' });
    } catch (error: any) {
      console.error('[SupportController] submitFeedback error:', error.message);
      res.status(500).json({ error: error.message });
    }
  }

  // GET /api/support/feedback
  static async getFeedbackHistory(req: AuthRequest, res: Response) {
    try {
      const userId = req.user?.userId;
      if (!userId) return res.status(401).json({ error: 'Unauthorized' });

      const rows = await supabaseRequest<any[]>({
        method: 'GET',
        path:   `${TABLE}?user_id=eq.${userId}&order=created_at.desc`,
      });

      res.json(rows ?? []);
    } catch (error: any) {
      console.error('[SupportController] getFeedbackHistory error:', error.message);
      res.status(500).json({ error: error.message });
    }
  }

  // POST /api/support/feedback/:id/respond
  static async respondToFeedback(req: AuthRequest, res: Response) {
    try {
      const { id }               = req.params;   // this is the feedback_id UUID
      const { response, status } = req.body;
      const adminId              = req.user?.userId;
      const isAdmin              = req.user?.role === 'admin';

      if (!isAdmin)   return res.status(403).json({ error: 'Only admins can respond to feedback' });
      if (!response)  return res.status(400).json({ error: 'Response message is required' });

      await supabaseRequest({
        method: 'PATCH',
        path:   `${TABLE}?feedback_id=eq.${id}`,
        prefer: 'return=minimal',
        body: {
          admin_response: response,
          status:         status || 'responded',
          responded_at:   new Date().toISOString(),
          admin_id:       adminId ?? null,
        },
      });

      res.json({ success: true, message: 'Response recorded successfully' });
    } catch (error: any) {
      console.error('[SupportController] respondToFeedback error:', error.message);
      res.status(500).json({ error: error.message });
    }
  }
}
