require 'xcodeproj'
require 'fileutils'

TEAM_ID = '6ZN7399P3U'
MAIN_BUNDLE_ID = 'org.reactjs.native.example.Nerox'
PACKET_BUNDLE_ID = "#{MAIN_BUNDLE_ID}.PacketTunnel"
MAIN_PROFILE = '4250a012-2d5e-4164-a0d9-3c6b59950937'
PACKET_PROFILE = 'ba9b8b32-6949-4963-a3a3-f3e7c6a50d94'

project_path = 'Nerox.xcodeproj'
project = Xcodeproj::Project.open(project_path)
nerox_target = project.targets.find { |t| t.name == 'Nerox' }
raise 'Nerox target not found' unless nerox_target

# 1. Configure Main Target
nerox_target.build_configurations.each do |config|
  config.build_settings['CODE_SIGN_STYLE'] = 'Manual'
  config.build_settings['DEVELOPMENT_TEAM'] = TEAM_ID
  config.build_settings['PRODUCT_BUNDLE_IDENTIFIER'] = MAIN_BUNDLE_ID
  config.build_settings['CODE_SIGN_ENTITLEMENTS'] = 'Nerox/Nerox.entitlements'
  config.build_settings['PROVISIONING_PROFILE'] = MAIN_PROFILE
  config.build_settings['PROVISIONING_PROFILE_SPECIFIER'] = MAIN_PROFILE
end

# Add WireGuardTunnel.m to Nerox target if not exists
nerox_group = project.main_group.find_subpath('Nerox', true)
wg_tunnel_m_path = 'WireGuardTunnel.m'
wg_file_ref = nerox_group.files.find { |f| f.path == wg_tunnel_m_path }
unless wg_file_ref
  wg_file_ref = nerox_group.new_file(wg_tunnel_m_path)
end
unless nerox_target.source_build_phase.files_references.include?(wg_file_ref)
  nerox_target.source_build_phase.add_file_reference(wg_file_ref, true)
end

# Add NetworkExtension.framework to Nerox
frameworks_group = project.frameworks_group
ne_fw_ref = frameworks_group.files.find { |f| f.path == 'System/Library/Frameworks/NetworkExtension.framework' }
unless ne_fw_ref
  ne_fw_ref = frameworks_group.new_file('System/Library/Frameworks/NetworkExtension.framework', :developer_dir)
end
unless nerox_target.frameworks_build_phase.files_references.include?(ne_fw_ref)
  nerox_target.frameworks_build_phase.add_file_reference(ne_fw_ref, true)
end

# 2. Configure PacketTunnel Target
packet_target = project.targets.find { |t| t.name == 'PacketTunnel' }
unless packet_target
  packet_target = project.new_target(:app_extension, 'PacketTunnel', :ios, '15.0')
end

# Create group if not exists
pt_group = project.main_group.find_subpath('PacketTunnel', true)
pt_group.set_source_tree('<group>')
pt_group.set_path('PacketTunnel')

def add_files_to_phase(group, target_phase, dir_path, extension)
  return unless Dir.exist?(dir_path)
  Dir.glob(File.join(dir_path, "*.#{extension}")).each do |file_path|
    file_name = File.basename(file_path)
    file_ref = group.files.find { |f| f.path == file_name || f.path == file_path }
    unless file_ref
      file_ref = group.new_file(file_path)
    end
    unless target_phase.files_references.include?(file_ref)
      target_phase.add_file_reference(file_ref, true)
    end
  end
end

# Add PacketTunnel files
pt_swift = pt_group.files.find { |f| f.path == 'PacketTunnelProvider.swift' || f.path == 'PacketTunnel/PacketTunnelProvider.swift' }
unless pt_swift
  pt_swift = pt_group.new_file('PacketTunnelProvider.swift')
end
unless packet_target.source_build_phase.files_references.include?(pt_swift)
  packet_target.source_build_phase.add_file_reference(pt_swift, true)
end

# Add WireGuardKit (.swift)
wgk_group = project.main_group.find_subpath('WireGuardKit', true)
wgk_group.set_source_tree('<group>')
add_files_to_phase(wgk_group, packet_target.source_build_phase, 'WireGuardKit', 'swift')

# Add WireGuardKitC (.c)
wgkc_group = project.main_group.find_subpath('WireGuardKitC', true)
wgkc_group.set_source_tree('<group>')
add_files_to_phase(wgkc_group, packet_target.source_build_phase, 'WireGuardKitC', 'c')

# Link NetworkExtension.framework to PacketTunnel
unless packet_target.frameworks_build_phase.files_references.include?(ne_fw_ref)
  packet_target.frameworks_build_phase.add_file_reference(ne_fw_ref, true)
end

# Link libwg-go.a to PacketTunnel
libwg_go_path = 'WireGuardKitGo/out/libwg-go.a'
libwg_go_ref = frameworks_group.files.find { |f| f.path == libwg_go_path || f.name == 'libwg-go.a' }
unless libwg_go_ref
  libwg_go_ref = frameworks_group.new_file(libwg_go_path)
end
unless packet_target.frameworks_build_phase.files_references.include?(libwg_go_ref)
  packet_target.frameworks_build_phase.add_file_reference(libwg_go_ref, true)
end

# Embed PacketTunnel in Nerox
embed_phase = nerox_target.build_phases.find do |phase|
  phase.is_a?(Xcodeproj::Project::Object::PBXCopyFilesBuildPhase) && phase.name == 'Embed App Extensions'
end
unless embed_phase
  embed_phase = nerox_target.new_copy_files_build_phase('Embed App Extensions')
  embed_phase.dst_subfolder_spec = '13'
end

extension_ref = packet_target.product_reference
unless embed_phase.files_references.include?(extension_ref)
  build_file = embed_phase.add_file_reference(extension_ref)
  build_file.settings = { 'ATTRIBUTES' => ['RemoveHeadersOnCopy', 'CodeSignOnCopy'] }
end

# Add Target Dependency
already_depends = nerox_target.dependencies.any? { |d| d.target == packet_target }
unless already_depends
  container_proxy = project.new(Xcodeproj::Project::Object::PBXContainerItemProxy)
  container_proxy.container_portal = project.root_object.uuid
  container_proxy.proxy_type = '1'
  container_proxy.remote_global_id_string = packet_target.uuid
  container_proxy.remote_info = packet_target.name
  target_dependency = project.new(Xcodeproj::Project::Object::PBXTargetDependency)
  target_dependency.target = packet_target
  target_dependency.target_proxy = container_proxy
  nerox_target.dependencies << target_dependency
end

# Configure PacketTunnel Build Settings
packet_target.build_configurations.each do |config|
  config.build_settings['SWIFT_VERSION'] = '5.0'
  config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '15.0'
  config.build_settings['CODE_SIGN_STYLE'] = 'Manual'
  config.build_settings['DEVELOPMENT_TEAM'] = TEAM_ID
  config.build_settings['PRODUCT_NAME'] = 'PacketTunnel'
  config.build_settings['PRODUCT_BUNDLE_IDENTIFIER'] = PACKET_BUNDLE_ID
  config.build_settings['CODE_SIGN_ENTITLEMENTS'] = 'PacketTunnel/PacketTunnel.entitlements'
  config.build_settings['GENERATE_INFOPLIST_FILE'] = 'NO'
  config.build_settings['INFOPLIST_FILE'] = 'PacketTunnel/Info.plist'
  config.build_settings['PROVISIONING_PROFILE'] = PACKET_PROFILE
  config.build_settings['PROVISIONING_PROFILE_SPECIFIER'] = PACKET_PROFILE
  
  # Swift & Header Search Paths for module maps
  config.build_settings['SWIFT_INCLUDE_PATHS'] = '$(SRCROOT)/WireGuardKitC $(SRCROOT)/WireGuardKitGo'
  
  config.build_settings['HEADER_SEARCH_PATHS'] ||= ['$(inherited)']
  config.build_settings['HEADER_SEARCH_PATHS'] << '$(SRCROOT)/WireGuardKitC'
  config.build_settings['HEADER_SEARCH_PATHS'] << '$(SRCROOT)/WireGuardKitGo'
  
  config.build_settings['LIBRARY_SEARCH_PATHS'] ||= ['$(inherited)']
  config.build_settings['LIBRARY_SEARCH_PATHS'] << '$(SRCROOT)/WireGuardKitGo/out'
end

project.save
puts 'Xcode project successfully updated for WireGuard!'
