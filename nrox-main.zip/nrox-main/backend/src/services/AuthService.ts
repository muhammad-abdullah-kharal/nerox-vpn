import pool from '../config/db';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';
import { OAuth2Client } from 'google-auth-library';

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// ─── IP Geolocation ───────────────────────────────────────────────────────────
// Uses ip-api.com (free, no API key needed, 45 req/min limit)
async function geolocateIp(ip: string): Promise<string | null> {
  try {
    // Skip private/localhost IPs
    if (!ip || ip === '::1' || ip.startsWith('127.') || ip.startsWith('192.168.') || ip.startsWith('10.')) {
      return null;
    }
    const cleanIp = ip.replace(/^::ffff:/, ''); // Strip IPv6 prefix
    const res = await fetch(`http://ip-api.com/json/${cleanIp}?fields=country`, { signal: AbortSignal.timeout(3000) });
    if (!res.ok) return null;
    const data: any = await res.json();
    return data?.country || null;
  } catch {
    return null;
  }
}

// ─── Save country to Supabase public.users ────────────────────────────────────
const SUPABASE_URL = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

async function saveCountryToSupabase(userId: string, country: string, ip: string): Promise<void> {
  if (!SUPABASE_URL || !SUPABASE_KEY || !country) return;
  try {
    await fetch(`${SUPABASE_URL}/rest/v1/users?user_id=eq.${userId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type':  'application/json',
        'apikey':        SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
        'Prefer':        'return=minimal',
      },
      body: JSON.stringify({ country_code: country, last_login_ip: ip }),
    });
  } catch (err) {
    console.warn('[AuthService] Failed to save country to Supabase:', err);
  }
}

const sendResendEmail = async (to: string, subject: string, text: string) => {
  const apiKey = process.env.RESEND_API_KEY || process.env.SMTP_PASS;
  const from = process.env.SMTP_FROM || process.env.SMTP_USER || 'noreply@neroxvpn.com';

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: `Nerox VPN <${from}>`,
      to: [to],
      subject,
      text
    })
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Resend API Error: ${response.status} ${errorBody}`);
  }
};

export class AuthService {

  // ─── Register (Sign Up) ───────────────────────────────────────────────
  static async register(email: string, password: string, username: string, referralCodeApplied?: string): Promise<any> {
    // Check if email already exists
    const existing = await pool.query('SELECT user_id FROM users WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      throw new Error('An account with this email already exists.');
    }

    const referralCode = Math.random().toString(36).substring(2, 10).toUpperCase();
    const passwordHash = await bcrypt.hash(password, 10);

    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();

    const { rows } = await pool.query(
      `INSERT INTO users (username, email, password_hash, plan_type, trial_ends_at, referral_code, is_verified, verification_code, verification_expires_at)
       VALUES ($1, $2, $3, 'free', NOW() + INTERVAL '7 days', $4, false, $5, NOW() + INTERVAL '15 minutes')
       RETURNING user_id, role, email`,
      [username, email, passwordHash, referralCode, verificationCode]
    );

    const user = rows[0];

    // Handle incoming referral code
    if (referralCodeApplied) {
      try {
        const { ReferralService } = require('./ReferralService');
        await ReferralService.applyReferral(user.user_id, referralCodeApplied);
      } catch (err) {
        console.warn(`[AuthService] Could not apply referral code ${referralCodeApplied}:`, err);
        // We don't block registration if referral fails
      }
    }

    try {
      await sendResendEmail(
        email,
        'Verify your Nerox VPN Account',
        `Your verification code is: ${verificationCode}\n\nIt expires in 15 minutes.`
      );
    } catch (err) {
      console.warn('[AuthService] Failed to send verification email', err);
    }

    return { requireVerification: true, email: user.email };
  }

  // ─── Login (Sign In) ──────────────────────────────────────────────────
  static async login(email: string, passwordRaw: string, clientIp = ''): Promise<any> {
    const { rows } = await pool.query(
      'SELECT user_id, password_hash, is_verified, locked_until, role FROM users WHERE email = $1',
      [email]
    );

    if (rows.length === 0) {
      throw new Error('No account found with this email.');
    }

    const user = rows[0];

    // Check if account is locked
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const remainingMinutes = Math.ceil((new Date(user.locked_until).getTime() - Date.now()) / 60000);
      throw new Error(`Account is locked due to too many failed attempts. Try again in ${remainingMinutes} minutes.`);
    }

    const isValid = await bcrypt.compare(passwordRaw, user.password_hash);
    if (!isValid) {
      throw new Error('Invalid email or password.');
    }

    if (!user.is_verified) {
      await this.sendOtp(email);
      return { requireVerification: true, email };
    }

    // Geolocate and update Supabase in the background (non-blocking)
    geolocateIp(clientIp).then(country => {
      if (country) saveCountryToSupabase(user.user_id, country, clientIp);
    });

    const token = jwt.sign(
      { userId: user.user_id, role: user.role },
      process.env.JWT_SECRET as string,
      { expiresIn: '30d' }
    );
    
    return { token };
  }

  static async sendOtp(email: string): Promise<any> {
    const { rows } = await pool.query('SELECT user_id, is_verified FROM users WHERE email = $1', [email]);
    if (rows.length === 0) throw new Error('No account found with this email.');
    const user = rows[0];

    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    await pool.query(
      `UPDATE users SET verification_code = $1, verification_expires_at = NOW() + INTERVAL '15 minutes' WHERE user_id = $2`,
      [verificationCode, user.user_id]
    );

    try {
      await sendResendEmail(
        email,
        'Verify your Nerox VPN Account',
        `Your verification code is: ${verificationCode}\n\nIt expires in 15 minutes.`
      );
    } catch (err: any) {
      console.warn(`[Mock Email] Failed to send to ${email}. SMTP Error:`, err.message);
      console.warn(`[Mock Email] OTP for ${email} is: ${verificationCode}`);
      // Do not throw an error so the user can still proceed to the OTP screen
      // and we can manually use the OTP from the server logs.
    }

    return { success: true, requireVerification: true };
  }

  static async verifyOtp(email: string, code: string): Promise<any> {
    const { rows } = await pool.query(
      'SELECT user_id, verification_code, verification_expires_at, role FROM users WHERE email = $1',
      [email]
    );

    if (rows.length === 0) throw new Error('No account found with this email.');
    const user = rows[0];

    if (!user.verification_code || user.verification_code !== code) {
      throw new Error('Invalid verification code.');
    }

    if (new Date(user.verification_expires_at) < new Date()) {
      throw new Error('Verification code has expired. Please request a new one.');
    }

    await pool.query(
      'UPDATE users SET is_verified = true, verification_code = NULL, verification_expires_at = NULL WHERE user_id = $1',
      [user.user_id]
    );

    return jwt.sign(
      { userId: user.user_id, role: user.role },
      process.env.JWT_SECRET as string,
      { expiresIn: '30d' }
    );
  }

  static async resetPassword(userId: string, newPasswordRaw: string): Promise<void> {
    const newPasswordHash = await bcrypt.hash(newPasswordRaw, 10);
    await pool.query(
      'UPDATE users SET password_hash = $1, failed_attempts = 0, locked_until = NULL WHERE user_id = $2',
      [newPasswordHash, userId]
    );
  }

  static async registerDevice(userId: string, deviceInfo: { deviceId: string, model: string, os: string }) {
    if (!deviceInfo || !deviceInfo.deviceId) return;
    
    await pool.query(
      `INSERT INTO user_devices (user_id, device_id, model, os, last_active_at)
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT (user_id, device_id) DO UPDATE SET 
         model = EXCLUDED.model, 
         os = EXCLUDED.os, 
         last_active_at = NOW()`,
      [userId, deviceInfo.deviceId, deviceInfo.model, deviceInfo.os]
    );
  }

  // ─── Google Sign In ────────────────────────────────────────────────────
  static async googleSignIn(idToken: string | null, clientIp = '', serverAuthCode?: string): Promise<any> {
    let payload: any;

    if (idToken) {
      // Standard flow: verify idToken directly
      const ticket = await googleClient.verifyIdToken({
        idToken,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      payload = ticket.getPayload();
    } else if (serverAuthCode) {
      // Fallback flow: exchange serverAuthCode for tokens
      const { tokens } = await googleClient.getToken({
        code: serverAuthCode,
        redirect_uri: 'postmessage',
      });
      if (!tokens.id_token) throw new Error('Could not exchange auth code for token.');
      const ticket = await googleClient.verifyIdToken({
        idToken: tokens.id_token,
        audience: process.env.GOOGLE_CLIENT_ID,
      });
      payload = ticket.getPayload();
    } else {
      throw new Error('No valid Google token provided.');
    }

    if (!payload || !payload.email) {
      throw new Error('Invalid Google token: could not retrieve email.');
    }

    const { email, name, picture } = payload;

    const existing = await pool.query(
      'SELECT user_id, role FROM users WHERE email = $1',
      [email]
    );

    let userId: string;
    let role: string;

    if (existing.rows.length > 0) {
      userId = existing.rows[0].user_id;
      role = existing.rows[0].role;
      await pool.query(
        `UPDATE users SET 
           is_verified = true,
           avatar_url = COALESCE(avatar_url, $1),
           display_name = COALESCE(display_name, $2)
         WHERE user_id = $3`,
        [picture || null, name || null, userId]
      );
    } else {
      const referralCode = Math.random().toString(36).substring(2, 10).toUpperCase();
      const username = (name || email.split('@')[0]).trim();

      const { rows } = await pool.query(
        `INSERT INTO users 
           (username, email, password_hash, plan_type, trial_ends_at, referral_code, is_verified, avatar_url, display_name)
         VALUES ($1, $2, NULL, 'free', NOW() + INTERVAL '7 days', $3, true, $4, $5)
         RETURNING user_id, role`,
        [username, email, referralCode, picture || null, name || null]
      );

      userId = rows[0].user_id;
      role = rows[0].role;
    }

    // Geolocate and update Supabase in the background (non-blocking)
    geolocateIp(clientIp).then(country => {
      if (country) saveCountryToSupabase(userId, country, clientIp);
    });

    const token = jwt.sign(
      { userId, role },
      process.env.JWT_SECRET as string,
      { expiresIn: '30d' }
    );

    return { token };
  }
}
