const { Client } = require('pg');
const c = new Client({ connectionString: 'postgresql://postgres:NewPassword123@localhost:5432/nerox_vpn' });

c.connect()
  .then(() => c.query(`SELECT email, plan_type, subscription_end_date FROM users WHERE plan_type = 'premium' ORDER BY created_at DESC`))
  .then(r => { 
    console.log(JSON.stringify(r.rows, null, 2)); 
    c.end(); 
  })
  .catch(e => { 
    console.error(e.message); 
    c.end(); 
  });
